<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Booklium
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'booklium' ); ?></a>

    <header id="masthead" class="site-header">
        <div class="site-branding">
            <?php
            if ( has_custom_logo() ) {
                the_custom_logo();
            } else {
                ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 457.001 457.001" fill="#a6a6a6" style="width: 40px; height: 40px;" role="img" aria-label="Castello Risano Logo">
                        <path d="M42.755 125.406c.178 2.901 2.583 5.163 5.489 5.163h71.548c2.551 0 4.768-1.754 5.354-4.237.39-1.652.587-3.307.587-4.919 0-11.769-9.575-21.344-21.344-21.344-2.759 0-5.44.523-7.946 1.536-4.61-5.051-11.195-8.036-18.177-8.036-8.98 0-17.272 5.011-21.551 12.753-8.083 2.014-14.012 9.324-14.012 17.935 0 .335.019.664.041.993l.011.156zm18.011-8.62c2.155-.124 4.039-1.497 4.815-3.511 2.01-5.207 7.106-8.705 12.685-8.705 4.883 0 9.417 2.646 11.832 6.905.78 1.376 2.116 2.35 3.665 2.672s3.162-.039 4.427-.99c1.813-1.365 3.956-2.086 6.199-2.086 5.074 0 9.308 3.673 10.179 8.5h-59.21c1.286-1.597 3.215-2.659 5.408-2.785z"/>
                    </svg>
                </a>
                <?php
            }
            ?>
        </div><!-- .site-branding -->

        <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
            <span class="menu-toggle-icon"></span>
        </button>

        <div class="main-navigation-wrapper">
            <nav id="site-navigation" class="main-navigation" aria-label="Primary Navigation">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'menu-1',
                    'menu_id'        => 'primary-menu',
                    'menu_class'     => 'menu primary-menu',
                ) );
                ?>
            </nav><!-- #site-navigation -->
        </div>

        <div class="social-menu-wrapper">
            <?php
            if ( function_exists( 'booklium_social_menu' ) ) {
                booklium_social_menu();
            }
            ?>
        </div>
    </header><!-- #masthead -->