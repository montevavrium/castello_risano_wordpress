<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Invalid request.', 'motopress-hotel-booking' ); ?>
</p>
