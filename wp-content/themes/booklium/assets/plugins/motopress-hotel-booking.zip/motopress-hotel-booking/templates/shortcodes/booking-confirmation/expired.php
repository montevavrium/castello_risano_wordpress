<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Your booking request is expired. Please start a new booking request.', 'motopress-hotel-booking' ); ?>
</p>
